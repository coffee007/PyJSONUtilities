from setuptools import find_packages, setup
setup(
    name='pyjsonutils',
    packages=find_packages(),
    version='0.3.0',
    description='Some basic functions used often with JSON files',
    author='Me',
    license='MIT',
)